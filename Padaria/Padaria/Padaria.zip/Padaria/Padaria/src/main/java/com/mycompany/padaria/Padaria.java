/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.padaria;

/**
 *
 * @author fernando.sccarmo
 */
public class Padaria {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
